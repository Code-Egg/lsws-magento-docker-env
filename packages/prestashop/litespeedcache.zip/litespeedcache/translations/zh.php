<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{litespeedcache}prestashop>litespeedcache_7a39408c6f201f8ffc1cf7ea77bdc7f1'] = 'LiteSpeed缓存模块';
$_MODULE['<{litespeedcache}prestashop>litespeedcache_e63887a3c31594f66d3768145e15e481'] = '与LiteSpeed服务器的页面缓存模块集成。';
$_MODULE['<{litespeedcache}prestashop>litespeedcache_ce6ef6c43f48dbb7b931991422e09269'] = 'LiteSpeed缓存';
$_MODULE['<{litespeedcache}prestashop>litespeedcache_34e34c43ec6b943c10a3cc1a1a16fb11'] = '管理';
$_MODULE['<{litespeedcache}prestashop>litespeedcache_254f642527b45bc260048e30704edb39'] = '配置';
$_MODULE['<{litespeedcache}prestashop>litespeedcache_da22c93ccb398c72070f4000cc7b59a1'] = '本地定制';
